/**
 * 
 */
package uisrael.poo.lab1;

/**
 * 
 */
public class HolaMundo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hola Mundo");

	}

}
